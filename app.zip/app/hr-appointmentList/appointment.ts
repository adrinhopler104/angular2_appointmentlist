// Appointment Class
export class Appointment {
    date                : string;                   
    description         : string;                    
    color               : string;
    tooltip             : string;
}