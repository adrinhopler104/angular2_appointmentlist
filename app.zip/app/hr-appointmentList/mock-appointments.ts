import { Appointment }          from './appointment'

export const APPOINTMENTS: Appointment[] = [
    { date:"15.10.2016", description:"Lorem ipsum dolor sit amet", color:"#30ace6", tooltip:"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium "},
    { date:"16.10.2016", description:"Damit Ihr indess", color:"#67afef", tooltip:"t vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis"},
    { date:"01.11.2016", description:"Äüöß", color:"#fcbfd3", tooltip:"Eine wunderbare Heiterkeit hat meine ganze Seele eingenommen, gleich den süßen Frühlingsmorgen, die ich mit ganzem Herzen genieße."},
    { date:"15.10.2017", description:"Lorem ipsum dolor sit amet", color:"#30ace6", tooltip:"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium"},
    { date:"16.10.2017", description:"Damit Ihr indess", color:"#67afef", tooltip:"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis"},
    { date:"01.11.2017", description:"Äüöß", color:"#fcbfd3", tooltip:"Eine wunderbare Heiterkeit hat meine ganze Seele eingenommen, gleich den süßen Frühlingsmorgen, die ich mit ganzem Herzen genieße."},
    { date:"15.10.2018", description:"Lorem ipsum dolor sit amet", color:"#30ace6", tooltip:"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium "},
    { date:"16.10.2018", description:"Damit Ihr indess", color:"#67afef", tooltip:"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis"},
    { date:"01.11.2018", description:"Äüöß", color:"#fcbfd3", tooltip:"Eine wunderbare Heiterkeit hat meine ganze Seele eingenommen, gleich den süßen Frühlingsmorgen, die ich mit ganzem Herzen genieße."},
    { date:"15.10.2019", description:"Lorem ipsum dolor sit amet", color:"background-color: #00ff00;", tooltip:"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium "},
    { date:"16.10.2019", description:"UDamit Ihr indess", color:"#67afef", tooltip:"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis"},
    { date:"01.11.2019", description:"Äüöß", color:"#fcbfd3", tooltip:"Eine wunderbare Heiterkeit hat meine ganze Seele eingenommen, gleich den süßen Frühlingsmorgen, die ich mit ganzem Herzen genieße."}
];
