"use strict";
// Appointment Class
var Appointment = (function () {
    function Appointment() {
    }
    return Appointment;
}());
exports.Appointment = Appointment;
//# sourceMappingURL=appointment.js.map